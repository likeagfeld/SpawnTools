"""The four Workbench tabs."""
